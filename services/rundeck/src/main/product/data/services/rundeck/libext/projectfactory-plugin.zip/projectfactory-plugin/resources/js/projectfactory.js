document.write('<' + 'script type="text/javascript" src="/portal/toolbar.php?tab=rundeck&amp;format=js"><' + '/script>');
